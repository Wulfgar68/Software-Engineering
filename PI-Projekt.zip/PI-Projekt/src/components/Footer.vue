<template>
  <footer class="fixed bottom-0 left-0 w-full h-10 bg-gray-800 text-white grid place-items-center z-40">
    <p>Projekt PI</p>
  </footer>
</template>